public interface ISample {

	public int m1();

	public int  m2(int nb);

	public void m3();

}