* Si besoin: Télécharger et installer [VirtualBox](https://www.virtualbox.org/wiki/Downloads) 
* Télécharger et installer [Vagrant](https://www.vagrantup.com/downloads.html) (5 min)

Note: L'installation peut nécessiter un redémarrage du PC.

Démarrer l'installation de la VM:

 ```# vagrant up```  (8 min)

 ```# vagrant provision```  (maj de la VM)

 Connexion:
 * login : root
 * pass : vagrant

Démarrage X11:

 ```# startx```
