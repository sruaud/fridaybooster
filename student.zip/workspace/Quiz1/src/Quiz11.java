public class Quiz11 {
	public static void main(String[] args) {
		Integer nombre1 = 33251;
		Integer nombre2 = 33251;

		System.out.println("Egalité: " + new Boolean(nombre1 == nombre2));
	}
}
