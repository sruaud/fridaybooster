public class Quiz2 {
	public static void main(String[] args) {
		Integer nombre1 = 12;
		Integer nombre2 = 12;

		System.out.println("Egalité: " + new Boolean(nombre1 == nombre2));
	}
}
