public class Forrest {

  public Runnable wrooom(){
    return () -> { System.out.println("Hello, lambda!"); };
  }
}

