class Counter {
	int val = 0;

	void inc() {
		val++;
	}

	void decr() {
		val--;
	}
}